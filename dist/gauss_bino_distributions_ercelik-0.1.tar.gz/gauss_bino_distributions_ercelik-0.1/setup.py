from setuptools import setup

setup(name = 'gauss_bino_distributions_ercelik',
      version = '0.1',
      description = 'Gaussian and Binomial distributions',
      packages = ['gauss_bino_distributions_ercelik'],
      author = 'Dilay Fidan Ercelik',
      author_email = 'dilay.ercelik@gmail.com',
      zip_safe = False)
